$(".regular").slick({
    // TODO:
});