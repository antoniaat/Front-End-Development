function notify(message) {
   // TODO:
}