function deleteByEmail() {
    // TODO:
}