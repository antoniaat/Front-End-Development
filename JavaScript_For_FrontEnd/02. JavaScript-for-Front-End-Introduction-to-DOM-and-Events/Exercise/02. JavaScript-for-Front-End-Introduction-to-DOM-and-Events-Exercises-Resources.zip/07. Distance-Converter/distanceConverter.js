function attachEventsListeners() {
    // TODO:
}