function toggle() {
     // TODO:
}