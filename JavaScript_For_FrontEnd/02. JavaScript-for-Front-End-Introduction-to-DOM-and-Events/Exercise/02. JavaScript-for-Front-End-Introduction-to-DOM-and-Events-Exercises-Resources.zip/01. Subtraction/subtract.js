function subtract() {
   // TODO:
}